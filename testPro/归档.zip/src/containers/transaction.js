import React,{Component} from 'react';
export default class Transaction extends Component{
    constructor(props){
        super(props);
        this.state = {

        }
    }
    componentDidMount(){
        
    }
    render(){
        return(
            <div>我是交易组件</div>
        )
    }
}