import React,{Component} from 'react';
export default class Analysis extends Component{
    constructor(props){
        super(props);
        this.state = {

        }
    }
    render(){
        return(
            <div>我是数据分析组件</div>
        )
    }
}