export default {
    test1:0,
    test2:1,
    center_moudle_index:0
}