export const LEFT = 'LEFT';
export const CENTER = 'CENTER';
export const RIGHT = 'RIGHT';
export const HEADER = 'HEADER';